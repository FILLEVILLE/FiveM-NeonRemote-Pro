if Locales == nil then Locales = {} end -- Skapar listan om den inte finns

Locales['sv'] = {
    ['not_in_veh'] = "Du måste sitta i ett fordon!",
    ['no_neon'] = "Detta fordon har inget neon installerat!",
    ['ui_title'] = "NEONKONTROLL",
    ['ui_s_minus'] = "S-",
    ['ui_s_plus'] = "S+",
    ['ui_custom_paint'] = "EGEN FÄRG",
    ['ui_rgb'] = "DISCO RGB",
    ['ui_stop'] = "STÄNG<br>AV",
    ['ui_start'] = "SÄTT<br>PÅ"
}